console.log("Welcome to Tic Tac Toe🌸");

let welcome = new Audio("welcome.mp3");
let audioturn = new Audio("beep.wav");
let gameover = new Audio("Gameover.mp3");
let winn = new Audio("success-fanfare-trumpets-6185.mp3");
let isgameover = false;

// Turn change
let turn = "X";
const changeTurn = () => {
  return turn === "X" ? "O" : "X";
};

// Function to check if there is a winner
const checkWin = () => {
  let boxtexts = document.getElementsByClassName('boxtext');
  let wins = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6],
  ];

 wins.forEach(e => {
    if (
      boxtexts[e[0]].innerText === boxtexts[e[1]].innerText &&
      boxtexts[e[1]].innerText === boxtexts[e[2]].innerText &&
      boxtexts[e[0]].innerText !== ""
    ) {
      console.log("Winner found:", boxtexts[e[0]].innerText);
      document.querySelector('.info').innerText = boxtexts[e[0]].innerText + " Won";
      isgameover = true;
      document.querySelector('.imagebox1').style.display = "block"; 
      console.log("Displaying second image.");
      
    }
  });
};

// Gamelogic
welcome.play()
let boxes = document.getElementsByClassName('box');
Array.from(boxes).forEach(element => {
  let boxtext = element.querySelector('.boxtext');
  element.addEventListener('click', function () {
    if (!isgameover && boxtext.innerText === '') { 
      boxtext.innerText = turn;
      turn = changeTurn();
      audioturn.play();
      checkWin();
      if (!isgameover) {
        document.querySelector('.info').innerText = 'Turn for ' + turn;
      }
    }
  });
});


//Listener of Reset
reset.addEventListener('click', () => {
  let boxtexts = document.querySelectorAll('.boxtext');
  Array.from(boxtexts).forEach(element => {
    element.innerText = ''; 
    turn = "X";
    isgameover = false;
    document.querySelector('.info').innerText = 'Turn for ' + turn;
    element.style.width = "0px"; 
  });

  document.querySelector('.imagebox1').style.display = "none";
  console.log("Image vanished.");
});


